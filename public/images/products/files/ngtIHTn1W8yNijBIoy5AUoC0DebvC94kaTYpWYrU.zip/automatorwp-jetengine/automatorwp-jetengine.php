<?php
/**
 * Plugin Name:           AutomatorWP - JetEngine
 * Plugin URI:            https://automatorwp.com/add-ons/jetengine/
 * Description:           Connect AutomatorWP with JetEngine.
 * Version:               1.0.1
 * Author:                AutomatorWP
 * Author URI:            https://automatorwp.com/
 * Text Domain:           automatorwp-jetengine
 * Domain Path:           /languages/
 * Requires at least:     4.4
 * Tested up to:          6.2
 * License:               GNU AGPL v3.0 (http://www.gnu.org/licenses/agpl.txt)
 *
 * @package               AutomatorWP\JetEngine
 * @author                AutomatorWP
 * @copyright             Copyright (c) AutomatorWP
 */

final class AutomatorWP_JetEngine {

    /**
     * @var         AutomatorWP_JetEngine $instance The one true AutomatorWP_JetEngine
     * @since       1.0.0
     */
    private static $instance;

    /**
     * Get active instance
     *
     * @access      public
     * @since       1.0.0
     * @return      AutomatorWP_JetEngine self::$instance The one true AutomatorWP_JetEngine
     */
    public static function instance() {
        if( !self::$instance ) {
            self::$instance = new AutomatorWP_JetEngine();
            self::$instance->constants();
            self::$instance->includes();
            self::$instance->hooks();
            self::$instance->load_textdomain();
        }

        return self::$instance;
    }

    /**
     * Setup plugin constants
     *
     * @access      private
     * @since       1.0.0
     * @return      void
     */
    private function constants() {
        // Plugin version
        define( 'AUTOMATORWP_JETENGINE_VER', '1.0.1' );

        // Plugin file
        define( 'AUTOMATORWP_JETENGINE_FILE', __FILE__ );

        // Plugin path
        define( 'AUTOMATORWP_JETENGINE_DIR', plugin_dir_path( __FILE__ ) );

        // Plugin URL
        define( 'AUTOMATORWP_JETENGINE_URL', plugin_dir_url( __FILE__ ) );
    }

    /**
     * Include plugin files
     *
     * @access      private
     * @since       1.0.0
     * @return      void
     */
    private function includes() {

        if( $this->meets_requirements() ) {

            // Includes
            require_once AUTOMATORWP_JETENGINE_DIR . 'includes/functions.php';

            // Triggers
            require_once AUTOMATORWP_JETENGINE_DIR . 'includes/triggers/publish-post-type.php';
            require_once AUTOMATORWP_JETENGINE_DIR . 'includes/triggers/delete-post-type.php';
            require_once AUTOMATORWP_JETENGINE_DIR . 'includes/triggers/update-post-type.php';

            

        }
    }

    /**
     * Setup plugin hooks
     *
     * @access      private
     * @since       1.0.0
     * @return      void
     */
    private function hooks() {

        add_action( 'automatorwp_init', array( $this, 'register_integration' ) );

        add_filter( 'automatorwp_licenses_meta_boxes', array( $this, 'license' ) );

        add_action( 'admin_notices', array( $this, 'admin_notices' ) );
    }

    /**
     * Registers this integration
     *
     * @since 1.0.0
     */
    function register_integration() {

        automatorwp_register_integration( 'jetengine', array(
            'label' => 'JetEngine',
            'icon'  => AUTOMATORWP_JETENGINE_URL . 'assets/jetengine.svg',
        ) );

    }

    /**
     * Licensing
     *
     * @since 1.0.0
     *
     * @param array $meta_boxes
     *
     * @return array
     */
    function license( $meta_boxes ) {

        $meta_boxes['automatorwp-jetengine-license'] = array(
            'title' => 'JetEngine',
            'fields' => array(
                'automatorwp_jetengine_license' => array(
                    'type' => 'edd_license',
                    'file' => AUTOMATORWP_JETENGINE_FILE,
                    'item_name' => 'JetEngine',
                ),
            )
        );

        return $meta_boxes;

    }

    /**
     * Plugin admin notices.
     *
     * @since  1.0.0
     */
    public function admin_notices() {

        if ( ! $this->meets_requirements() && ! defined( 'AUTOMATORWP_ADMIN_NOTICES' ) ) : ?>

            <div id="message" class="notice notice-error is-dismissible">
                <p>
                    <?php printf(
                        __( 'AutomatorWP - JetEngine requires %s and %s in order to work. Please install and activate them.', 'automatorwp-jetengine' ),
                        '<a href="https://wordpress.org/plugins/automatorwp/" target="_blank">AutomatorWP</a>',
                        '<a href="https://crocoblock.com/plugins/jetengine/" target="_blank">JetEngine</a>'
                    ); ?>
                </p>
            </div>

            <?php define( 'AUTOMATORWP_ADMIN_NOTICES', true ); ?>

        <?php endif;

    }

    /**
     * Check if there are all plugin requirements
     *
     * @since  1.0.0
     *
     * @return bool True if installation meets all requirements
     */
    private function meets_requirements() {

        if ( ! class_exists( 'AutomatorWP' ) ) {
            return false;
        }

        if ( ! class_exists( '\Jet_Engine' ) ) {
            return false;
        }

        return true;

    }

    /**
     * Internationalization
     *
     * @access      public
     * @since       1.0.0
     * @return      void
     */
    public function load_textdomain() {

        // Set filter for language directory
        $lang_dir = AUTOMATORWP_JETENGINE_DIR . '/languages/';
        $lang_dir = apply_filters( 'automatorwp_jetengine_languages_directory', $lang_dir );

        // Traditional WordPress plugin locale filter
        $locale = apply_filters( 'plugin_locale', get_locale(), 'automatorwp-jetengine' );
        $mofile = sprintf( '%1$s-%2$s.mo', 'automatorwp-jetengine', $locale );

        // Setup paths to current locale file
        $mofile_local   = $lang_dir . $mofile;
        $mofile_global  = WP_LANG_DIR . '/automatorwp-jetengine/' . $mofile;

        if( file_exists( $mofile_global ) ) {
            // Look in global /wp-content/languages/automatorwp-jetengine/ folder
            load_textdomain( 'automatorwp-jetengine', $mofile_global );
        } elseif( file_exists( $mofile_local ) ) {
            // Look in local /wp-content/plugins/automatorwp-jetengine/languages/ folder
            load_textdomain( 'automatorwp-jetengine', $mofile_local );
        } else {
            // Load the default language files
            load_plugin_textdomain( 'automatorwp-jetengine', false, $lang_dir );
        }

    }

}

/**
 * The main function responsible for returning the one true AutomatorWP_JetEngine instance to functions everywhere
 *
 * @since       1.0.0
 * @return      \AutomatorWP_JetEngine The one true AutomatorWP_JetEngine
 */
function AutomatorWP_JetEngine() {
    return AutomatorWP_JetEngine::instance();
}
add_action( 'plugins_loaded', 'AutomatorWP_JetEngine' );
