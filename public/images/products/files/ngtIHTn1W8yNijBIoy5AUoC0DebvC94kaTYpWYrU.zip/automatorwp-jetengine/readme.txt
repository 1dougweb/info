=== AutomatorWP - JetEngine ===
Contributors: automatorwp, rubengc, eneribs, dioni00
Tags: jet, engine, automatorwp, content, types, custom, fields, dynamic
Requires at least: 4.4
Tested up to: 6.2
Stable tag: 1.0.1
License: GNU AGPLv3
License URI: http://www.gnu.org/licenses/agpl-3.0.html

Connect AutomatorWP with JetEngine

== Description ==

[JetEngine](https://crocoblock.com/plugins/jetengine/ "JetEngine") is a dynamic content and custom field plugin. Create post and content types, taxonomy templates, query data from DB tables, and visualize them as tables and graphs.

= Triggers =

* User publishes a post of a type.
* User updates a post of a type.
* User deletes a post of a type.

== Installation ==

= From WordPress backend =

1. Navigate to Plugins -> Add new.
2. Click the button "Upload Plugin" next to "Add plugins" title.
3. Upload the downloaded zip file and activate it.

= Direct upload =

1. Upload the downloaded zip file into your `wp-content/plugins/` folder.
2. Unzip the uploaded zip file.
3. Navigate to Plugins menu on your WordPress admin area.
4. Activate this plugin.

== Changelog ==

= 1.0.1 =

* **Improvements**
* Triggers work only with JetEngine types.
* **Bug Fixes**
* Fixed PHP Warning

= 1.0.0 =

* Initial release.
